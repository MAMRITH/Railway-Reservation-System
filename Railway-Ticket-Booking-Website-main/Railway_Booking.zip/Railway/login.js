// let radio = function () {
    
// }


let course ={
    name: 'JS',
    price: 33,
    description: 'A good JS Course to learn'
}

console.log(course);